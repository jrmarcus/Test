<?php include 'view/header.php'; ?>
<div id="main">
    <h1>Menu</h1>
    <p><a href="product_manager">Product Manager</a></p>
    <p><a href="product_catalog">Product Catalog</a></p>
</div>
<?php include 'view/footer.php'; ?>