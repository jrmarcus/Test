<?php include '../view/header.php'; ?>
<?php include '../view/sidebar.php'; ?>
<div id="content">
    <!-- display product -->
    <?php include '../view/product.php'; ?>

</div><!-- end content -->
<?php include '../view/footer.php'; ?>